function availability(host_id){
  for(j=0; j<the_array.length; j++){
    if(host_id == the_array[j][1]){
  status = "Yes";
  break;
    }else{
  status = "No";
    }
  }
  if (status=="No") {
   j=1;
   the_array[j][0]="0000000000000";
  }
date_array = [['Jun<BR/>2-9'],['Jun<BR/>9-16'],['Jun<BR/>16-23'],['Jun<BR/>23-30'],['Jun&nbsp;30<BR/>Jul&nbsp;7'],['Jul<BR/>7-14'],['Jul<BR/>14-21'],['Jul<BR/>21-28'],['Jul&nbsp;28<BR/>Aug&nbsp;4'],['Aug<BR/>4-11'],['Aug<BR/>11-18'],['Aug<BR/>18-25'],['Aug&nbsp;25<BR/>Sep&nbsp;1']]
date_array2 = [['GbZeYxDUkiF2NkUV6Da%2fug%3d%3d%3ah2snrIG3nPnKpMSHF0t0FQ%3d%3d'],['h2snrIG3nPnKpMSHF0t0FQ%3d%3d%3aLlgdyxeTAt7jMbG%2bkK9ckQ%3d%3d'],['LlgdyxeTAt7jMbG%2bkK9ckQ%3d%3d%3ajrJ82wvhT8cbKP1rv8CM8w%3d%3d'],['jrJ82wvhT8cbKP1rv8CM8w%3d%3d%3a%2fXL4UYLwySEY4zbpTwjTTQ%3d%3d'],['%2fXL4UYLwySEY4zbpTwjTTQ%3d%3d%3a9gxT8w2qR8wdfaN82gNGMw%3d%3d'],['9gxT8w2qR8wdfaN82gNGMw%3d%3d%3aV4pQMAZnOmSAM%2bLYwZoZOA%3d%3d'],['V4pQMAZnOmSAM%2bLYwZoZOA%3d%3d%3aEq5pxBblEmKp4%2bu%2fBNxBgQ%3d%3d'],['Eq5pxBblEmKp4%2bu%2fBNxBgQ%3d%3d%3akJL3w6n6fO%2bT7GtioSznsQ%3d%3d'],['kJL3w6n6fO%2bT7GtioSznsQ%3d%3d%3aytiSOwtzO0w%2f%2fgCf3%2b4XHg%3d%3d'],['ytiSOwtzO0w%2f%2fgCf3%2b4XHg%3d%3d%3au9RKHI2hBxNEn9F7vhI2KA%3d%3d'],['u9RKHI2hBxNEn9F7vhI2KA%3d%3d%3aNllQAxKnS7TETD8P%2bZGeyA%3d%3d'],['NllQAxKnS7TETD8P%2bZGeyA%3d%3d%3a8ozZ0KK9%2brvlHvopbYEOcg%3d%3d'],['8ozZ0KK9%2brvlHvopbYEOcg%3d%3d%3aJS5Okc9ldrO20DuvYLQ2ug%3d%3d']]

document.write('<div class="AvailabilityChart">\n<div class="divTableBody">\n<div class="divTableRow">\n')
  for(i=0; i<date_array.length; i++){
      green = '<div class="divTableCell PropOpen">' + date_array[i][0] + '</div>\n';
      red = '<div class="divTableCell PropReserved">' + date_array[i][0] + '</div>\n';
      yellow = '<div class="divTableCell PropHold">' + date_array[i][0] + '</div>\n';
  if(the_array[j][0].substr(i,1) == 1){
    cell_color = red;
  }else if(the_array[j][0].substr(i,1) == 2){
    cell_color = yellow;
  }else{
    cell_color = green;
  }
  document.write(cell_color) ;
  }
  document.write('</div>\n<div class="divTableRow">\n')
for(i=0; i<date_array.length; i++){
    green = '<div class="divTableCell PropOpen"><a href="http://dev.Cstayreserve.com/Reserve.aspx?PropID=' + host_id + '&Week=' + date_array2[i][0] + '"  >Book</a></div>\n';
    red = '<div class="divTableCell PropReserved">N/A</div>\n';
    yellow = '<div class="divTableCell PropHold">On Hold</div>\n';
if(the_array[j][0].substr(i,1) == 1){
cell_color = red;
}else if(the_array[j][0].substr(i,1) == 2){
cell_color = yellow;
}else{
cell_color = green;
}
document.write(cell_color) ;
}
  document.write('</div></div>')
}
